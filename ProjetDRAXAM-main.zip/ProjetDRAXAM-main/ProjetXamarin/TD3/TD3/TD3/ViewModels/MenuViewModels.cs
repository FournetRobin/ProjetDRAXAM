﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;


namespace TD3.ViewModels
{
    public class MenuViewModels : INotifyPropertyChanged
    {
        public ICommand ValiderVille
        {
            get
            {
                return new Command(ChangerPage);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        string VilleSelectionner = "";

        public void OnPropertyChanged(string Ville)
        {
            if (PropertyChanged == null)
            {
                return;
            }
            PropertyChanged(this, new PropertyChangedEventArgs(Ville));
        }

        private string ville = string.Empty;
        public string Ville
        {
            get
            {
                return ville;
            }
            set
            {
                if (ville == value)
                    return;

                ville = value;
                OnPropertyChanged("Ville");
            }
        }

        void ChangerPage()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                await Application.Current.MainPage.Navigation.PushAsync(new MainPage(Ville));
            });
        }
    }
}
